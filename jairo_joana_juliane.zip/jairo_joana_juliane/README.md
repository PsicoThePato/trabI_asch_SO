# trabI_asch_SO
#implementação de um shell asch para a disciplina de sistemas operacionais
#Para rodar, simplesmente digite {make run}. Perceba que os comandos têm uma restrição de 1000 caracteres.
